﻿var baseAddress = 'http://localhost:1902/api/Student/';
var url = '';

var app = angular.module('MyModule', ['ngRoute']);
app.config(function ($routeProvider, $locationProvider) {
    $routeProvider
    .when('/', { templateUrl: '/MyPages/Default.html' })
    .when('/Student', { templateUrl: '/MyPages/Student.html', controller: 'StudentCtrl' })
    .otherwise({ redirectTo: '/' });
    $locationProvider.hashPrefix('');
})

app.factory('myFactor', function ($http) {
    var factories = {};
    factories.SaveStudent = function (objStudent) {
        url = baseAddress + 'PostStudent';
        return $http.post(url, objStudent);
    }
    factories.UpdateStudent = function (objStudent) {
        url = baseAddress + objStudent.ID;
        return $http.put(url, objStudent)
    }
    factories.GetStudent = function () {
        return $http.get(baseAddress);
    }
    factories.DeleteStudent = function (id) {
        url = baseAddress + id;
        return $http.delete(url);
    }
    return factories;
})
app.controller('StudentCtrl', function ($scope, myFactor) {
    Clear()
    function studentList() {
        myFactor.GetStudent().then(function (res) {
            $scope.students = res.data;
            Clear();
        })
    }

    $scope.getAllStudent = studentList;
    $scope.EditStudent = function (s) {
        $scope.ID = s.ID;
        $scope.Name = s.Name;
        $scope.Address = s.Address;

        $scope.Action = 'Update';
    }
    $scope.SaveButton = function () {
        if ($scope.Action == 'Save') {
            var Student = {
                'Name': $scope.Name,
                'Address': $scope.Address
            }
            myFactor.SaveStudent(Student).then(function () {
                studentList();
            })
        }
        else {
            var student = {
                'ID': $scope.ID,
                'Name': $scope.Name,
                'Address': $scope.Address
            }
            myFactor.UpdateStudent(student).then(function (res) {
                studentList();
            })
        }
    }
    $scope.DeleteButton = function (id) {
        myFactor.DeleteStudent(id).then(function (res) {
            studentList();
            Clear()
        })
    }
    function Clear() {
        $scope.Action = 'Save';
        $scope.Name = '';
        $scope.Address = '';
    }
})
